            
        </main>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    </div>
    <script>
        // Tangani perubahan URL dengan menggunakan popstate event
        window.addEventListener("popstate", function(event) {
            // Periksa URL atau lakukan tindakan lainnya sesuai kebutuhan
            var currentURL = window.location.href;
            console.log("URL berubah: " + currentURL);

            // Anda dapat menambahkan kode untuk memuat data tambahan atau melakukan tindakan lainnya
            // sesuai dengan URL yang baru.

            // Contoh: Ambil data dengan HTMX
            htmx.ajax({url: currentURL, target: "#content"});
        });
        
        // Cari semua elemen dengan kelas .modal-backdrop yang lebih dari satu
var modalBackdrops = document.querySelectorAll('.modal-backdrop');

// Periksa jika ada lebih dari satu .modal-backdrop
if (modalBackdrops.length > 1) {
    // Hapus semua kecuali yang pertama
    for (var i = 1; i < modalBackdrops.length; i++) {
        modalBackdrops[i].parentNode.removeChild(modalBackdrops[i]);
    }
}

    </script>


    </body>
</html><?php /**PATH C:\laragon\www\kosmin\resources\views/layouts/footer.blade.php ENDPATH**/ ?>