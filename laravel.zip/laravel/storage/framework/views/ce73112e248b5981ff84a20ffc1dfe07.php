<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="row m-4">
    
    <div class="col-sm-4 mb-3">
        <div class="card border-0" style="cursor: pointer;">
            <div class="card-body" onclick="location.href='<?php echo e(route('payment.index')); ?>';">
                <h5 class="card-title">Payment</h5>
                <p class="card-text"><?php echo e($paymentMessage); ?></p>
                
            </div>
        </div>
    </div>
    <div class="col-sm-4 mb-3">
        <div class="card border-0" style="cursor: pointer;">
            <div class="card-body" onclick="location.href='<?php echo e(route('guest.index')); ?>';">
                <h5 class="card-title">Guest</h5>
                <p class="card-text"><?php echo e($guestMessage); ?></p>
                
            </div>
        </div>
    </div>
    <div class="col-sm-4 mb-3">
        <div class="card border-0" style="cursor: pointer;">
            <div class="card-body" onclick="location.href='<?php echo e(route('room.index')); ?>';">
                <h5 class="card-title">Room</h5>
                <p class="card-text"><?php echo e($roomMessage); ?></p>
               
            </div>
        </div>
    </div>
    <div class="col-sm-4 mb-3">
        <div class="card border-0" style="cursor: pointer;">
            <div class="card-body" onclick="location.href='<?php echo e(route('activity.index')); ?>';">
                <h5 class="card-title">Recent</h5>
                <ul>
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($activity->description); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kosmin\resources\views/dashboard.blade.php ENDPATH**/ ?>