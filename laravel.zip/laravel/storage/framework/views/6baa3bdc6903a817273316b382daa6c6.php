

<?php $__env->startSection('title', 'Payment'); ?>

<?php $__env->startSection('content'); ?>

<div class="card mx-auto mt-4 col-11 col-lg-8">
    <button type="button" class="btn btn-light custom-btn m-3 mb-1" style="border: none;" data-bs-toggle="modal" data-bs-target="#createPaymentModal">
        Create
    </button>

    <div class="modal" id="createPaymentModal" tabindex="-1" aria-labelledby="createPaymentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="createPaymentModalLabel">Create Payment</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form method="POST" action="<?php echo e(route('payment.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="input-group mb-3 row">
                            <label for="firstGuest_id" class="col-sm-3 col-form-label">First Guest</label>
                            <div class="col-sm-9">
                                <select class="form-control" id="firstGuest_id" name="firstGuest_id">
                                    <option value="">Select First Guest</option>
                                    <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($guest->id); ?>"><?php echo e($guest->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
            
                        <div class="input-group mb-3 row">
                            <label for="secondGuest_id" class="col-sm-3 col-form-label">Second Guest</label>
                            <div class="col-sm-9">
                                <select class="form-control" id="secondGuest_id" name="secondGuest_id">
                                    <option value="">Select Second Guest</option>
                                    <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($guest->id); ?>"><?php echo e($guest->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        

                        <div class="input-group mb-3 row">
                            <label for="room_id" class="col-sm-3 col-form-label">Room</label>
                            <div class="col-sm-9">
                                <select class="form-control" id="room_id" name="room_id">
                                    <option value="">Select Room</option>
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="input-group mb-3 row">
                            <label for="paid_date" class="col-sm-3 col-form-label">Payment Date</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" id="paid_date" name="paid_date">
                            </div>
                        </div>

                        <div class="input-group mb-3 row">
                            <label for="amount" class="col-sm-3 col-form-label">Amount</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-text" id="basic-addon3">Rp</span>
                                    <input type="text" class="form-control" id="amount" name="amount">
                                </div>
                            </div>
                        </div>

                        <div class="input-group mb-3 row">
                            <label for="description" class="col-sm-3 col-form-label">Description</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" id="description" name="description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Confirm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-borderless">
                <thead class="table-group-divider">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Room</th>
                        <th scope="col">Guest</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                        <td><?php echo e($payment->room->name); ?></td>
                        <td>
                            <?php if($payment->firstGuest): ?>
                                <?php echo e($payment->firstGuest->name); ?>

                            <?php endif; ?>

                            <?php if($payment->secondGuest): ?>
                                & <?php echo e($payment->secondGuest->name); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($payment->amount); ?></td>
                        <td class="d-flex justify-content-start">
                            <button type="button" class="btn me-1" data-bs-toggle="modal" data-bs-target="#deletePaymentModal<?php echo e($loop->index + 1); ?>"
                                style="--bs-btn-padding-y: 0rem; --bs-btn-padding-x: .25rem;">
                                Delete
                            </button>
                            <div class="modal" id="deletePaymentModal<?php echo e($loop->index + 1); ?>" tabindex="-1" aria-labelledby="deletePaymentModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="deletePaymentModalLabel">Delete Payment</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form method="POST" action="<?php echo e(route('payment.destroy', $payment->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-body">
                                                <p>Are you sure you want to delete this payment?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>500</td>
                        <td><button type="button" class="btn"
                                style="--bs-btn-padding-y: 0rem; --bs-btn-padding-x: .25rem;">Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td colspan="2">Larry the Bird</td>
                        <td>750</td>
                        <td><button type="button" class="btn"
                                style="--bs-btn-padding-y: 0rem; --bs-btn-padding-x: .25rem;">Delete</button>
                        </td>
                    </tr>
                </tbody>
                
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kosmin\resources\views/payment/index.blade.php ENDPATH**/ ?>