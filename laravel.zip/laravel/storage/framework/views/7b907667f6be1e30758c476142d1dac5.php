

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

    <div class="bg-light d-flex vh-100 align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-4">
                    <div class="d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('img/ui/building.svg')); ?>" alt="Building" class="img-fluid small-svg mb-3">
                        <h1>KOSMIN</h1>
                        <p>Welcome Back!</p>
                    </div>    
                    <div class="card border-0 mt-2">
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('login.post')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group mb-3">
                                    <label for="username"><?php echo e(__('Username')); ?></label>
                                    <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                                </div>

                                <div class="form-group mb-3">
                                    <label for "password"><?php echo e(__('Password')); ?></label>
                                    <input id="password" type="password" class="form-control" name="password" required>
                                </div>

                                <div class="d-grid gap-2 d-md-block">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </form>
                                <?php if($showRegisterButton): ?>
                                
                                <a class="btn btn-light custom-btn mt-1" tabindex="-1" role="button" href="<?php echo e(route('register')); ?>" style="border: none;">
                                    Register
                                </a>
                                <?php endif; ?>
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger mt-3">
                                    <?php echo e(__('Login Failed')); ?>

                                </div>
                                <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kosmin\resources\views/auth/login.blade.php ENDPATH**/ ?>